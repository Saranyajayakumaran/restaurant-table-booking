'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'square-full';
var width = 512;
var height = 512;
var aliases = [128997,128998,128999,129000,129001,129002,129003,11035,11036];
var unicode = 'f45c';
var svgPathData = 'M464 48V464H48V48H464zM48 0H0V48 464v48H48 464h48V464 48 0H464 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSquareFull = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;